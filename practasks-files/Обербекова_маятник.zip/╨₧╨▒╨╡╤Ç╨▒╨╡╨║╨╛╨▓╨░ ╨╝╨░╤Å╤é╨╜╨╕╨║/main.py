from math import sqrt

eps = [4.01, 4.03, 4.02, 4.04, 4.06] ## 1

mid = 0
for i in eps:
    mid += i

mid = mid/len(eps)

sum_rand = 0
for i in eps:
    sum_rand += (i - mid)**2

t = 2
delta_eps_rand = t*sqrt(sum_rand/len(eps)/(len(eps)-1))

print("Delta eps_1_rand =", delta_eps_rand)

eps = [2.87, 2.88, 2.84, 2.83, 2.88]  # 2

mid = 0
for i in eps:
    mid += i

mid = mid/len(eps)

sum_rand = 0
for i in eps:
    sum_rand += (i - mid)**2

t = 2
delta_eps_rand = t*sqrt(sum_rand/len(eps)/(len(eps)-1))

print("Delta eps_2_rand =", delta_eps_rand)

Jc = [0.00163, 0.00161, 0.00151, 0.00144, 0.00155]
Mid_Jc = 0
for i in Jc:
    Mid_Jc += i

Mid_Jc /= len(Jc)

print("Mid_J_c =", Mid_Jc)
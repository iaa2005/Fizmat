import math

# Данные из Таблиц №1 и №2
m = 52.0 / 1000
d = 30.0 / 1000
m0 = 105.0 / 1000
r1 = 70.0 / 1000
r2 = 100.0 / 1000
delta_m = 0.5 / 1000
delta_d = 0.5 / 1000
delta_m0 = 0.5 / 1000
delta_r1 = 0.5 / 1000
delta_r2 = 0.5 / 1000
eps1 = 4.03
eps2 = 2.86

# Коэффициент Стьюдента
# Для 5 измерений t равен:
t = 2.13


# Расчет среднего углового ускорения eps1:
eps_i = [4.01, 4.03, 4.02, 4.04, 4.06]  # 1
mid = 0
for i in eps_i:
    mid += i
mid = mid/len(eps_i)
sum_rand = 0
for i in eps_i:
    sum_rand += (i - mid)**2
delta_eps_rand = t * math.sqrt(sum_rand/len(eps_i)/(len(eps_i)-1))
delta_eps1 = delta_eps_rand
print("∆ε1_rand =", delta_eps_rand)


# Расчет среднего углового ускорения eps2:
eps_i = [2.87, 2.88, 2.84, 2.83, 2.88]  # 2
mid = 0
for i in eps_i:
    mid += i
mid = mid/len(eps_i)
sum_rand = 0
for i in eps_i:
    sum_rand += (i - mid)**2
delta_eps_rand = t * math.sqrt(sum_rand/len(eps_i)/(len(eps_i)-1))
delta_eps2 = delta_eps_rand
print("∆ε2_rand =", delta_eps_rand)

# Расчет среднего момента инерции Jc:
print("Jc =", 4*m*(r2**2*eps2 - r1**2*eps1)/(eps1 - eps2) - m0*d**2/4)

# Расчет косвенной погрешности ∆Jc момента инерции Jc:
Delta_Jc = math.sqrt((4 * m * (eps2 * r2 ** 2 - eps1 * r1 ** 2) / (eps1 - eps2) ** 2 + 4 * m * r1 ** 2 / (eps1 - eps2)) ** 2 * delta_eps1 ** 2 +
                     (4 * m * (eps2 * r2 ** 2 - eps1 * r1 ** 2) / (eps1 - eps2) ** 2 + 4 * m * r2 ** 2 / (eps1 - eps2)) ** 2 * delta_eps2 ** 2 +
                     (8 * m * eps1 * r1 * delta_r1 / (eps1 - eps2)) ** 2 +
                     (8 * m * eps2 * r2 * delta_r2 / (eps1 - eps2)) ** 2 +
                     ((4 * eps2 * r2 ** 2 - 4 * eps1 * r1 ** 2) * delta_m / (eps1 - eps2)) ** 2 +
                     (d ** 2 * delta_m0 / 4) ** 2 + (d * m0 * delta_d / 2) ** 2)
print("∆Jc =", Delta_Jc)

# Среднее арифметическое Jc_mid было посчитано:
eps_i_1 = [4.01, 4.03, 4.02, 4.04, 4.06]
eps_i_2 = [2.87, 2.88, 2.84, 2.83, 2.88]

Jc_mid = 0
print("Jic = [ ", end="")
for i in range(5):
    print(4 * m * (r2 ** 2 * eps_i_2[i] - r1 ** 2 * eps_i_1[i]) / (eps_i_1[i] - eps_i_2[i]) - m0 * d ** 2 / 4, end=" ")
    Jc_mid += 4 * m * (r2 ** 2 * eps_i_2[i] - r1 ** 2 * eps_i_1[i]) / (eps_i_1[i] - eps_i_2[i]) - m0 * d ** 2 / 4
Jc_mid /= 5
print(" ]\nJc_mid =", Jc_mid)

# Относительная погрешность δJc для Jc:
delta_Jc = Delta_Jc/Jc_mid*100
print("δJc =", delta_Jc)
# Roman collects numbers that seem interesting to him. For example, now he considers positive numbers interesting, the entry of which in the number system with the base k ends with an odd number of zeros. For example, for k=2, such numbers are 2_10 = 10_2, 24_10 = 11000_2.
# In order to replenish his collection, Roman wants to find the nth such number in ascending order. Since he took n large enough, he can't do it manually.
# Help Roman — write a program that will find the number he needs to replenish the collection.
#  
# Input file format
# The first line of the input file contains two integers.
#  
# Output file format
# In the output file, output the nth number in ascending order, whose entry in the number system with the base k ends with an odd number of zeros. This number must be output in decimal notation.
#  
# Restrictions
# 1 ≤ n ≤ 10^15
# 2 ≤ k ≤ 10
#
# Sample Input 1
# 1 2
# Sample Output 1
# 2
#
# Sample Input 2
# 10 10
# Sample Output 2
# 110



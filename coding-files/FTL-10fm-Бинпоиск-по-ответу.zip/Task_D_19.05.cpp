#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <climits>
using namespace std;

int main() {
    int n, m, k;
    cin >> m >> n;
    vector<int> t(n), y(n), z(n), next(n);
    vector<int> done(n);
    for (int i = 0; i < n; ++i) {
        cin >> t[i] >> z[i] >> y[i];
        next[i] = t[i];
    }
    fill(done.begin(), done.end(), 0);
    int time = 0;
    for (int i = 0; i < m; ++i) {
        int min = INT_MAX;
        for (int j = 0; j < n; ++j) {
            if (next[j] < min) {
                k = j;
                min = next[j];
            }
        }
        time = next[k];
        ++done[k];
        next[k] = next[k] + t[k];
        if (done[k] % z[k] == 0) {
            next[k] = next[k] + y[k];
        }
    }
    cout << time << endl;
    for (int i = 0; i < n; ++i) {
        cout << done[i] << " ";
    }
    return 0;
}
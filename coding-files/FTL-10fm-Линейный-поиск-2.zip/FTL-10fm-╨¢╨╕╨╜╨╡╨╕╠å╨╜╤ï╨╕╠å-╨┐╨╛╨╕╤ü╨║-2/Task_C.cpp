//    Задана матрица K, содержащая n строк и m столбцов. Седловой точкой этой матрицы назовем элемент,
//    который одновременно является минимумом в своей строке и максимумом в своем столбце.
//
//    Найдите количество седловых точек заданной матрицы.
//
//    Входные данные
//    Первая строка содержит целые числа n и m (1 ≤ n, m ≤ 750). Далее следуют n строк по m чисел в каждой.
//    j-ое число i-ой строки равно kij. Все kij по модулю не превосходят 1000.
//
//    Выходные данные
//    Выведите ответ на задачу.
//
//    Примеры
//    входные данные
//    2 2
//    0 0
//    0 0
//    выходные данные
//    4
//    входные данные
//    2 2
//    1 2
//    3 4
//    выходные данные
//    1


#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    vector< vector<int> > matrix(n, vector<int>(m));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> matrix[i][j];
        }
    }

    // get array of min values in each row
    vector<int> min_row(n);
    for (int i = 0; i < n; i++) {
        min_row[i] = matrix[i][0];
        for (int j = 1; j < m; j++) {
            if (matrix[i][j] < min_row[i]) {
                min_row[i] = matrix[i][j];
            }
        }
    }

    // get array of max values in each column
    vector<int> max_col(m);
    for (int j = 0; j < m; j++) {
        max_col[j] = matrix[0][j];
        for (int i = 1; i < n; i++) {
            if (matrix[i][j] > max_col[j]) {
                max_col[j] = matrix[i][j];
            }
        }
    }



    int saddle_points = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (matrix[i][j] == min_row[i] && matrix[i][j] == max_col[j]) {
                saddle_points++;
            }
        }
    }
    cout << saddle_points << endl;
    return 0;
}
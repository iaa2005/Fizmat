n = int(input())
values = input().split()
s = []
for item in values:
    s.append(int(item))


def gcd(a, b):
    if (b == 0):
        return a
    else:
        return gcd(b, a % b)


def gcd_n(n, values):
    if n == 0:
        return -1
    if n == 1:
        return values[0]
    gcd_value = gcd(values[0], values[1])
    for i in range(2, n, 1):
        gcd_value = gcd(gcd_value, values[i])
    return gcd_value


print(gcd_n(n, s))

n = int(input())
i = 2
k = 0
if n % i:
    j = 3
    while j * j < n + 1:
        if not n % j:
            k = 1
            i = j
            break
        j += 2
else:
    k = 1
if k:
    print((i - 1) * (n // i), n // i)
else:
    print(1, n - 1)

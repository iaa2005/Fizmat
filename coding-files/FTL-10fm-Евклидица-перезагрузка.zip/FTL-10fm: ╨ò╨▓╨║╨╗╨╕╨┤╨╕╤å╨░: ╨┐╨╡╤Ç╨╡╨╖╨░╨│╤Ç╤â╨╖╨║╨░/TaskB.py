x1, y1, x2, y2 = map(int, input().split())
k = 0
if x1 == x2:
    x = x1
    x1 = y1
    y1 = x
    x = x2
    x2 = y2
    y2 = x
if x1 > x2:
    x = x1
    x1 = x2
    x2 = x
    x = y1
    y1 = y2
    y2 = x
for x in range(x1 + 1, x2 + 1, 1):
    if (x - x1) * (y2 - y1) % (x2 - x1) == 0:
        k += 1
print(k + 1)
k = int(input())
m = (45 * k) + (5 * (k - 2))
h = 8 + (m // 60)
m = m % 60
print(h, m + 5)
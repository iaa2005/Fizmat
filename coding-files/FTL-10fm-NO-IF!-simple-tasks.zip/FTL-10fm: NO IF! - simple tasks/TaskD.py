n = int(input())
a = n % 2
print(n + 2 - a * 1)
k, n = map(int, input().split())
fullPages = (n - 1) // k
restLines = (n - 1) % k
print(fullPages + 1, restLines + 1)

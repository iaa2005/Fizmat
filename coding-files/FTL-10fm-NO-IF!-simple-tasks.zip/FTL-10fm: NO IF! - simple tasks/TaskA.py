a, b, L, N = map(int, input().split())
print(2 * L + (2 * N - 1) * a + 2 * (N - 1) * b)
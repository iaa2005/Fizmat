#include <iostream>
#include <cmath>

using namespace std;
int main() {
    int a, b, c, f, g;
    cin >> a >> b;
    f = a;
    g = b;
    a = abs(a);
    if (a < b)
    {
        c = b;
        b = a;
        a = c;
    }
    else
    {
        c = a;
    }
    while (a != 0 && b != 0)
    {
        a = b;
        b = c % b;
        c = a;
    }
    f = f / a;
    g = g / a;
    cout << f << " " << g;
    return 0;
}
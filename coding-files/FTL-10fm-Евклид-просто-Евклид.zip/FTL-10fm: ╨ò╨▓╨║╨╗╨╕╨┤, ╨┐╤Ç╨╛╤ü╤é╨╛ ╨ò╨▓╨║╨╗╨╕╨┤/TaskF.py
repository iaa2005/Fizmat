def gcd(a, b):
    if b == 0:
        return a
    else:
        return gcd(b, a % b)


a, b = map(int, input().split())
if a == 1:
    print(b)
elif b == 1:
    print(a)
else:
    a = gcd(a - 1, b - 1)
    print(a + 1)

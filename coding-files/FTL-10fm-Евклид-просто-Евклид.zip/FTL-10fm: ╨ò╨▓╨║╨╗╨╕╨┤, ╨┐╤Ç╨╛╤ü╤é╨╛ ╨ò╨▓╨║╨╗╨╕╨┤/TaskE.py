def NOD(var1, var2):
    while var1 != var2:
        if var1 > var2:
            var1 -= var2
        else:
            var2 -= var1
    return var1


a, b, c, d = map(int, input().split())

m = a * d + b * c
n = b * d

nod = NOD(m, n)

print(int(m/nod), int(n/nod))
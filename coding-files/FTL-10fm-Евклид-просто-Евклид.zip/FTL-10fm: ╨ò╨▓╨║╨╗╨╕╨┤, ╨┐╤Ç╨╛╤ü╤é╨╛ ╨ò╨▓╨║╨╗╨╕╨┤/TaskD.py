a, b = map(int, input().split())
for i in range(101, -101, -1):
    if i != 0 and a % i == 0 and b % i == 0:
        print(a // i, b // i)
        break
    else:
        i -= 1

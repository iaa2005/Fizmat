def NOD(var1, var2):
    while var1 != var2:
        if var1 > var2:
            var1 -= var2
        else:
            var2 -= var1
    return var1

def NOK(var1, var2):
    return (var1 * var2) / NOD(var1, var2)

N, K = map(int, input().split())

print(int(NOK(N, K)))
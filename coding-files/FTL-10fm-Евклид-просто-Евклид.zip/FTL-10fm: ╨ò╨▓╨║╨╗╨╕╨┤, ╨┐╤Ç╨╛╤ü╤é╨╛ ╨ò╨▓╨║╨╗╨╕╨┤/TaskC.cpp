#include <iostream>
#include <cmath>
using namespace std;

int gcd(int e, int n) {
    int j;
    if (e < n) {
        j = n;
        n = e;
        e = j;
    }
    else {
        j = e;
    }
    while (e != 0 && n != 0) {
        e = n;
        n = j % n;
        j = e;
    }
    return e;
}

int lcm(int var1, int var2) {
    return (var1 * var2) / gcd(var1, var2);
}

int main() {
    int N, K;
    cin >> N >> K;
    cout << lcm(N, K) << endl;
    return 0;
}
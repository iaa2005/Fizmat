#include <iostream>
#include <cmath>

using namespace std;

int gcd(int e, int n)
{
    int j;
    if (e < n)
    {
        j = n;
        n = e;
        e = j;
    }
    else
    {
        j = e;
    }
    while (e != 0 && n != 0)
    {
        e = n;
        n = j % n;
        j = e;
    }
    return e;
}

int main() {
    int a, b;
    cin >> a >> b;
    if (a == 1) cout << b;
    else if (b == 1) cout << a;
    else {
        a = gcd(a - 1, b - 1);
        cout << a + 1 << endl;
    }
    return 0;
}
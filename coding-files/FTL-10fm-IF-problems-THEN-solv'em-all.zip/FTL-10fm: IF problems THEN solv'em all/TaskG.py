a, b, c = (int(i) for i in input().split())
k = 0
if b < 2 or c < 3:
    print(0)
else:
    k = a // (c - 2)
    if a % (c - 2) != 0:
        k += 1
    if b // k < 2:
        print(0)
    else:
        k = (a + b) // c
        if (a + b) % c != 0:
            k += 1
        print(k)


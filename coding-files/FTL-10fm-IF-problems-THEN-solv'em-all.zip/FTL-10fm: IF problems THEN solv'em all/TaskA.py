i, j = map(int, input().split())
if i != j:
    print(i + j - 1)
else:
    print(0)

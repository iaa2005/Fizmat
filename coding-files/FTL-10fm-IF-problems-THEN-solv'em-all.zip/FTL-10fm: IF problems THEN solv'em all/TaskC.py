a, b, c = map(int, input().split())

if a == 0 and b == 0 and c == 0:
    print('MANY SOLUTIONS')
else:
    if a == 0:
        print('NO SOLUTION')
    else:
        c = c * c
        k = c - b
        x = k / a
        if x > - b / a:
            print('NO SOLUTION')
        else:
            print(int(x))

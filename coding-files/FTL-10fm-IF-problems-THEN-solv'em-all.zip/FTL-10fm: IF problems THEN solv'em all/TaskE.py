n = int(input())
if n in range(11, 15):
    print(n, 'korov')
else:
    temp = n % 10
    if temp in list(range(5, 10)) + [0]:
        print(n, 'korov')
    if temp == 1:
        print(n, 'korova')
    if temp in range(2, 5):
        print(n, 'korovy')

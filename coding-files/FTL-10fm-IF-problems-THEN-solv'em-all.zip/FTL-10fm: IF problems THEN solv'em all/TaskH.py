D, F = map(int, input().split())
if (D + F-1) % 7 > 0:
    print((D + F - 1) // 7 + 1)
else:
    print((D + F - 1) // 7)

#include <cmath>
#include <iostream>
using namespace std;
int main()
{
  int H, W, h, w, t, d2;
  cin >> h >> w >> H >> W;
  if (W < H)
  {
    t = W;
    W = H;
    H = t;
  }
  if (h >= w)
  {
    t = h;
    h = w;
  }
  else
    t = w;
  d2 = t * t + h * h;
  if (h <= H && t <= W || H * sqrt(d2 - W * W) + W * sqrt(d2 - H * H) <= t * t - h * h)
    cout << "Possible";
  else
    cout << "Impossible";
  return 0;
}